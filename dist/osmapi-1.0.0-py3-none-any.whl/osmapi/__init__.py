from osmapi.core import get_relation_as_polygon as get_relation
from osmapi.core import get_way_as_line_string as get_way
from osmapi.core import get_node_as_latlng as get_node
